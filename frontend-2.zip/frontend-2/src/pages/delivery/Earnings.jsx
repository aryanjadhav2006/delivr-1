import Navbar from '../../components/layout/Navbar';
import Footer from '../../components/layout/Footer';

const Earnings = () => {
    return (
        <div>
            <Navbar />
            <div className="container" style={{ padding: '40px 20px' }}>
                <h1>Earnings</h1>
                <p>Earnings dashboard coming soon!</p>
            </div>
            <Footer />
        </div>
    );
};

export default Earnings;
