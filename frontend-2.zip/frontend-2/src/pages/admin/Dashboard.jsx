import Navbar from '../../components/layout/Navbar';
import Footer from '../../components/layout/Footer';

const Dashboard = () => {
    return (
        <div>
            <Navbar />
            <div className="container" style={{ padding: '40px 20px' }}>
                <h1>Admin Dashboard</h1>
                <p>Admin dashboard with stats coming soon!</p>
            </div>
            <Footer />
        </div>
    );
};

export default Dashboard;
