import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import Navbar from '../../components/layout/Navbar';
import Footer from '../../components/layout/Footer';
import { FaStar, FaClock, FaHeart, FaRegHeart } from 'react-icons/fa';
import './Favorites.css';

const Favorites = () => {
    const { user, updateUser } = useAuth();
    const [favorites, setFavorites] = useState([]);

    useEffect(() => {
        // In real implementation, fetch restaurant details for favorites from API
        // For now, display favorites from user object
        setFavorites(user?.favorites || []);
    }, [user]);

    const handleToggleFavorite = (restaurantId) => {
        const updatedFavorites = favorites.includes(restaurantId)
            ? favorites.filter((id) => id !== restaurantId)
            : [...favorites, restaurantId];

        setFavorites(updatedFavorites);
        updateUser({ ...user, favorites: updatedFavorites });
    };

    return (
        <div className="favorites-page">
            <Navbar />

            <div className="container" style={{ padding: '40px 20px' }}>
                <h1>Favorite Restaurants</h1>

                {favorites.length > 0 ? (
                    <div className="favorites-grid">
                        <div className="placeholder-message">
                            <p>Your favorite restaurants will appear here</p>
                            <Link to="/home" className="btn btn-primary">
                                Browse Restaurants
                            </Link>
                        </div>
                    </div>
                ) : (
                    <div className="no-favorites">
                        <FaHeart className="heart-icon" />
                        <h2>No favorites yet</h2>
                        <p>Start adding your favorite restaurants to see them here</p>
                        <Link to="/home" className="btn btn-primary">
                            Browse Restaurants
                        </Link>
                    </div>
                )}
            </div>

            <Footer />
        </div>
    );
};

export default Favorites;
