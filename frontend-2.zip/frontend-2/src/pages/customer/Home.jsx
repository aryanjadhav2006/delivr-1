// import { useState, useEffect } from 'react';
// import { Link } from 'react-router-dom';
// import Navbar from '../../components/layout/Navbar';
// import Footer from '../../components/layout/Footer';
// // removed api import since we use DummyJSON directly
// import { useLocation } from '../../context/LocationContext';
// import { FaStar, FaClock, FaSearch, FaFilter } from 'react-icons/fa';
// import './Home.css';

// const DUMMY_BASE = 'https://dummyjson.com';

// const Home = () => {
//     const [restaurants, setRestaurants] = useState([]);
//     const [allProducts, setAllProducts] = useState([]); // raw DummyJSON products
//     const [cuisines, setCuisines] = useState([]);
//     const [cities, setCities] = useState([]);
//     const [loading, setLoading] = useState(true);
//     const [filters, setFilters] = useState({
//         search: '',
//         cuisine: '',
//         minRating: '',
//         maxPrice: '',
//         city: '',
//     });

//     const { selectedCity, setSelectedCity } = useLocation();

//     useEffect(() => {
//         // fetch initial data once
//         fetchProductsAndMeta();
//         // eslint-disable-next-line react-hooks/exhaustive-deps
//     }, []);

//     useEffect(() => {
//         // whenever filters or selectedCity change, apply client-side filtering
//         applyFilters();
//         // eslint-disable-next-line react-hooks/exhaustive-deps
//     }, [filters, selectedCity, allProducts]);

//     // Fetch a chunk of products and derive cuisines/cities from them
//     const fetchProductsAndMeta = async () => {
//         try {
//             setLoading(true);
//             const res = await fetch(`${DUMMY_BASE}/products?limit=100`);
//             if (!res.ok) throw new Error('Failed to fetch products from DummyJSON');
//             const json = await res.json();
//             const products = json.products || [];

//             // Save raw products for client-side filtering
//             setAllProducts(products);

//             // derive cuisines from category field
//             const uniqueCuisines = Array.from(new Set(products.map((p) => p.category))).filter(Boolean);
//             setCuisines(uniqueCuisines);

//             // derive cities from brand field (brands as demo 'city' values)
//             const uniqueCities = Array.from(new Set(products.map((p) => p.brand))).filter(Boolean);
//             setCities(uniqueCities);

//             // initial restaurants list (mapped)
//             const mapped = products.map(mapProductToRestaurant);
//             setRestaurants(mapped);
//         } catch (error) {
//             console.error('Error fetching products (dummy):', error);
//             setAllProducts([]);
//             setCuisines([]);
//             setCities([]);
//             setRestaurants([]);
//         } finally {
//             setLoading(false);
//         }
//     };

//     const mapProductToRestaurant = (p) => ({
//         _id: String(p.id),
//         name: p.title,
//         image: p.thumbnail || (p.images && p.images[0]) || '',
//         cuisines: p.category ? [p.category] : ['Multi'],
//         area: p.brand || 'Demo Area',
//         city: p.brand || 'Demo City',
//         avgRating: p.rating || 4.2,
//         deliveryTime: 20 + (p.price ? (p.price % 20) : 0),
//         avgPrice: p.price || 250,
//         raw: p,
//     });

//     const applyFilters = () => {
//         if (!allProducts || allProducts.length === 0) {
//             setRestaurants([]);
//             return;
//         }

//         setLoading(true);

//         // start with all products
//         let filtered = [...allProducts];

//         // search filter (title or description)
//         if (filters.search) {
//             const q = filters.search.toLowerCase();
//             filtered = filtered.filter(
//                 (p) =>
//                     (p.title && p.title.toLowerCase().includes(q)) ||
//                     (p.description && p.description.toLowerCase().includes(q))
//             );
//         }

//         // cuisine filter -> category
//         if (filters.cuisine) {
//             filtered = filtered.filter((p) => p.category === filters.cuisine);
//         }

//         // selectedCity or filters.city -> brand
//         const cityFilter = selectedCity || filters.city;
//         if (cityFilter) {
//             filtered = filtered.filter((p) => p.brand === cityFilter);
//         }

//         // minRating
//         if (filters.minRating) {
//             const min = Number(filters.minRating);
//             if (!Number.isNaN(min)) {
//                 filtered = filtered.filter((p) => Number(p.rating) >= min);
//             }
//         }

//         // maxPrice
//         if (filters.maxPrice) {
//             const max = Number(filters.maxPrice);
//             if (!Number.isNaN(max)) {
//                 filtered = filtered.filter((p) => Number(p.price) <= max);
//             }
//         }

//         // map to restaurant shape
//         const mapped = filtered.map(mapProductToRestaurant);

//         setRestaurants(mapped);
//         setLoading(false);
//     };

//     const handleCityChange = (city) => {
//         setSelectedCity(city);
//         setFilters({ ...filters, city });
//     };

//     const handleCuisineFilter = (cuisine) => {
//         setFilters({ ...filters, cuisine: filters.cuisine === cuisine ? '' : cuisine });
//     };

//     return (
//         <div className="home-page">
//             <Navbar />

//             <div className="container">
//                 {/* Hero Section */}
//                 <div className="hero-section">
//                     <h1>Order Food from Your Favorite Restaurants</h1>
//                     <div className="search-bar-container">
//                         <FaSearch className="search-icon" />
//                         <input
//                             type="text"
//                             placeholder="Search for restaurants or dishes..."
//                             value={filters.search}
//                             onChange={(e) => setFilters({ ...filters, search: e.target.value })}
//                             className="search-input"
//                         />
//                     </div>
//                 </div>

//                 {/* City Selector */}
//                 <div className="city-selector">
//                     <label>Select City:</label>
//                     <select
//                         value={selectedCity || filters.city}
//                         onChange={(e) => handleCityChange(e.target.value)}
//                         className="city-dropdown"
//                     >
//                         <option value="">All Cities</option>
//                         {cities.map((city) => (
//                             <option key={city} value={city}>
//                                 {city}
//                             </option>
//                         ))}
//                     </select>
//                 </div>

//                 {/* Cuisine Filter */}
//                 <div className="cuisine-filter">
//                     <h3>Browse by Cuisine</h3>
//                     <div className="cuisine-chips">
//                         {cuisines.slice(0, 10).map((cuisine) => (
//                             <button
//                                 key={cuisine}
//                                 className={`cuisine-chip ${filters.cuisine === cuisine ? 'active' : ''}`}
//                                 onClick={() => handleCuisineFilter(cuisine)}
//                             >
//                                 {cuisine}
//                             </button>
//                         ))}
//                     </div>
//                 </div>

//                 {/* Filters */}
//                 <div className="filters-section">
//                     <div className="filter-item">
//                         <FaFilter />
//                         <label>Min Rating:</label>
//                         <select
//                             value={filters.minRating}
//                             onChange={(e) => setFilters({ ...filters, minRating: e.target.value })}
//                         >
//                             <option value="">Any</option>
//                             <option value="4">4+ Stars</option>
//                             <option value="3.5">3.5+ Stars</option>
//                             <option value="3">3+ Stars</option>
//                         </select>
//                     </div>

//                     <div className="filter-item">
//                         <label>Max Price:</label>
//                         <select
//                             value={filters.maxPrice}
//                             onChange={(e) => setFilters({ ...filters, maxPrice: e.target.value })}
//                         >
//                             <option value="">Any</option>
//                             <option value="300">Under ₹300</option>
//                             <option value="500">Under ₹500</option>
//                             <option value="1000">Under ₹1000</option>
//                         </select>
//                     </div>
//                 </div>

//                 {/* Restaurants Grid */}
//                 <div className="restaurants-section">
//                     <h2>
//                         {filters.cuisine || selectedCity
//                             ? `${filters.cuisine || ''} Restaurants ${selectedCity ? `in ${selectedCity}` : ''}`
//                             : 'Popular Restaurants'}
//                     </h2>

//                     {loading ? (
//                         <div className="loading">Loading restaurants...</div>
//                     ) : restaurants.length > 0 ? (
//                         <div className="restaurants-grid">
//                             {restaurants.map((restaurant) => (
//                                 <Link
//                                     to={`/restaurant/${restaurant._id}`}
//                                     key={restaurant._id}
//                                     className="restaurant-card"
//                                 >
//                                     <div className="restaurant-image">
//                                         <img src={restaurant.image} alt={restaurant.name} />
//                                     </div>
//                                     <div className="restaurant-info">
//                                         <h3>{restaurant.name}</h3>
//                                         <p className="cuisines">
//                                             {restaurant.cuisines.slice(0, 3).join(', ')}
//                                         </p>
//                                         <p className="location">
//                                             {restaurant.area}, {restaurant.city}
//                                         </p>
//                                         <div className="restaurant-meta">
//                                             <span className="rating">
//                                                 <FaStar /> {Number(restaurant.avgRating).toFixed(1)}
//                                             </span>
//                                             <span className="delivery-time">
//                                                 <FaClock /> {restaurant.deliveryTime} mins
//                                             </span>
//                                             <span className="price">₹{restaurant.avgPrice} for two</span>
//                                         </div>
//                                     </div>
//                                 </Link>
//                             ))}
//                         </div>
//                     ) : (
//                         <div className="no-results">
//                             <p>No restaurants found. Try adjusting your filters.</p>
//                         </div>
//                     )}
//                 </div>
//             </div>

//             <Footer />
//         </div>
//     );
// };

// export default Home;
























import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import Navbar from '../../components/layout/Navbar';
import Footer from '../../components/layout/Footer';
import api from '../../utils/api';
import { useLocation } from '../../context/LocationContext';
import { FaStar, FaClock, FaSearch, FaFilter } from 'react-icons/fa';
import './Home.css';

const Home = () => {
    const [restaurants, setRestaurants] = useState([]);
    const [cuisines, setCuisines] = useState([]);
    const [cities, setCities] = useState([]);
    const [loading, setLoading] = useState(true);
    const [filters, setFilters] = useState({
        search: '',
        cuisine: '',
        minRating: '',
        maxPrice: '',
        city: '',
    });

    const { selectedCity, setSelectedCity } = useLocation();

    useEffect(() => {
        fetchCuisines();
        fetchCities();
        fetchRestaurants();
    }, []);

    useEffect(() => {
        fetchRestaurants();
    }, [filters, selectedCity]);

    const fetchCuisines = async () => {
        try {
            const response = await api.get('/restaurants/cuisines');
            setCuisines(response.data.data || []);
        } catch (error) {
            console.error('Error fetching cuisines:', error);
        }
    };

    const fetchCities = async () => {
        try {
            const response = await api.get('/restaurants/locations');
            setCities(response.data.data.cities || []);
        } catch (error) {
            console.error('Error fetching cities:', error);
        }
    };

    const fetchRestaurants = async () => {
        try {
            setLoading(true);
            const params = new URLSearchParams();

            if (filters.search) params.append('search', filters.search);
            if (filters.cuisine) params.append('cuisine', filters.cuisine);
            if (filters.minRating) params.append('minRating', filters.minRating);
            if (filters.maxPrice) params.append('maxPrice', filters.maxPrice);
            if (selectedCity || filters.city) params.append('city', selectedCity || filters.city);

            const response = await api.get(`/restaurants?${params.toString()}`);
            setRestaurants(response.data.data || []);
        } catch (error) {
            console.error('Error fetching restaurants:', error);
            setRestaurants([]);
        } finally {
            setLoading(false);
        }
    };

    const handleCityChange = (city) => {
        setSelectedCity(city);
        setFilters({ ...filters, city });
    };

    const handleCuisineFilter = (cuisine) => {
        setFilters({ ...filters, cuisine: filters.cuisine === cuisine ? '' : cuisine });
    };

    return (
        <div className="home-page">
            <Navbar />

            <div className="container">
                {/* Hero Section */}
                <div className="hero-section">
                    <h1>Order Food from Your Favorite Restaurants</h1>
                    <div className="search-bar-container">
                        <FaSearch className="search-icon" />
                        <input
                            type="text"
                            placeholder="Search for restaurants or dishes..."
                            value={filters.search}
                            onChange={(e) => setFilters({ ...filters, search: e.target.value })}
                            className="search-input"
                        />
                    </div>
                </div>

                {/* City Selector */}
                <div className="city-selector">
                    <label>Select City:</label>
                    <select
                        value={selectedCity || filters.city}
                        onChange={(e) => handleCityChange(e.target.value)}
                        className="city-dropdown"
                    >
                        <option value="">All Cities</option>
                        {cities.map((city) => (
                            <option key={city} value={city}>
                                {city}
                            </option>
                        ))}
                    </select>
                </div>

                {/* Cuisine Filter */}
                <div className="cuisine-filter">
                    <h3>Browse by Cuisine</h3>
                    <div className="cuisine-chips">
                        {cuisines.slice(0, 10).map((cuisine) => (
                            <button
                                key={cuisine}
                                className={`cuisine-chip ${filters.cuisine === cuisine ? 'active' : ''}`}
                                onClick={() => handleCuisineFilter(cuisine)}
                            >
                                {cuisine}
                            </button>
                        ))}
                    </div>
                </div>

                {/* Filters */}
                <div className="filters-section">
                    <div className="filter-item">
                        <FaFilter />
                        <label>Min Rating:</label>
                        <select
                            value={filters.minRating}
                            onChange={(e) => setFilters({ ...filters, minRating: e.target.value })}
                        >
                            <option value="">Any</option>
                            <option value="4">4+ Stars</option>
                            <option value="3.5">3.5+ Stars</option>
                            <option value="3">3+ Stars</option>
                        </select>
                    </div>

                    <div className="filter-item">
                        <label>Max Price:</label>
                        <select
                            value={filters.maxPrice}
                            onChange={(e) => setFilters({ ...filters, maxPrice: e.target.value })}
                        >
                            <option value="">Any</option>
                            <option value="300">Under ₹300</option>
                            <option value="500">Under ₹500</option>
                            <option value="1000">Under ₹1000</option>
                        </select>
                    </div>
                </div>

                {/* Restaurants Grid */}
                <div className="restaurants-section">
                    <h2>
                        {filters.cuisine || selectedCity
                            ? `${filters.cuisine || ''} Restaurants ${selectedCity ? `in ${selectedCity}` : ''}`
                            : 'Popular Restaurants'}
                    </h2>

                    {loading ? (
                        <div className="loading">Loading restaurants...</div>
                    ) : restaurants.length > 0 ? (
                        <div className="restaurants-grid">
                            {restaurants.map((restaurant) => (
                                <Link
                                    to={`/restaurant/${restaurant._id}`}
                                    key={restaurant._id}
                                    className="restaurant-card"
                                >
                                    <div className="restaurant-image">
                                        <img src={restaurant.image} alt={restaurant.name} />
                                    </div>
                                    <div className="restaurant-info">
                                        <h3>{restaurant.name}</h3>
                                        <p className="cuisines">
                                            {restaurant.cuisines.slice(0, 3).join(', ')}
                                        </p>
                                        <p className="location">
                                            {restaurant.area}, {restaurant.city}
                                        </p>
                                        <div className="restaurant-meta">
                                            <span className="rating">
                                                <FaStar /> {restaurant.avgRating.toFixed(1)}
                                            </span>
                                            <span className="delivery-time">
                                                <FaClock /> {restaurant.deliveryTime} mins
                                            </span>
                                            <span className="price">₹{restaurant.avgPrice} for two</span>
                                        </div>
                                    </div>
                                </Link>
                            ))}
                        </div>
                    ) : (
                        <div className="no-results">
                            <p>No restaurants found. Try adjusting your filters.</p>
                        </div>
                    )}
                </div>
            </div>

            <Footer />
        </div>
    );
};

export default Home;
