// import { useState, useEffect } from 'react';
// import { useParams, useNavigate } from 'react-router-dom';
// import Navbar from '../../components/layout/Navbar';
// import Footer from '../../components/layout/Footer';
// import { useCart } from '../../context/CartContext';
// import { FaStar, FaClock, FaLeaf, FaPlus, FaMinus } from 'react-icons/fa';
// import './RestaurantMenu.css';

// /**
//  * DummyJSON-backed RestaurantMenu for quick demo/presentation.
//  * Mapping decisions:
//  *  - Restaurant detail: GET https://dummyjson.com/products/{id}
//  *  - Menu: GET https://dummyjson.com/products?limit=100 filtered by category === restaurant.category
//  *  - Product -> menu item mapping normalizes id -> _id (string) so existing cart logic works
//  *  - isVeg is heuristically inferred from product title/description
//  */

// const DUMMY_BASE = 'https://dummyjson.com';

// const RestaurantMenu = () => {
//     const { id } = useParams();
//     const navigate = useNavigate();
//     const { addToCart, cartItems, updateQuantity } = useCart();

//     const [restaurant, setRestaurant] = useState(null);
//     const [menuItems, setMenuItems] = useState([]);
//     const [loading, setLoading] = useState(true);
//     const [vegOnly, setVegOnly] = useState(false);

//     useEffect(() => {
//         fetchRestaurant();
//         // eslint-disable-next-line react-hooks/exhaustive-deps
//     }, [id]);

//     useEffect(() => {
//         // Re-fetch menu when restaurant changes or vegOnly toggles
//         fetchMenu();
//         // eslint-disable-next-line react-hooks/exhaustive-deps
//     }, [restaurant, vegOnly]);

//     const fetchRestaurant = async () => {
//         try {
//             setLoading(true);
//             // Use DummyJSON product as a mock "restaurant"
//             const res = await fetch(`${DUMMY_BASE}/products/${id}`);
//             if (!res.ok) throw new Error('Restaurant not found on DummyJSON');
//             const data = await res.json();

//             // Map DummyJSON product -> restaurant model used in your UI
//             const mapped = {
//                 id: String(data.id),
//                 name: data.title || 'Demo Restaurant',
//                 image: data.thumbnail || (data.images && data.images[0]) || '',
//                 cuisines: data.category ? [data.category] : ['Multi'],
//                 area: data.brand || 'Demo Area',
//                 city: 'Demo City',
//                 avgRating: data.rating || 4.2,
//                 deliveryTime: 20 + (data.price ? (data.price % 20) : 0),
//                 avgPrice: data.price || 250,
//                 raw: data, // keep original if needed
//             };

//             setRestaurant(mapped);
//         } catch (error) {
//             console.error('Error fetching restaurant (dummy):', error);
//             setRestaurant(null);
//         } finally {
//             setLoading(false);
//         }
//     };

//     const guessIsVeg = (title = '', description = '') => {
//         const text = `${title} ${description}`.toLowerCase();
//         const vegKeywords = ['veg', 'vegetable', 'salad', 'paneer', 'tofu', 'vegetarian', 'falafel', 'spinach', 'lentil', 'dal'];
//         return vegKeywords.some((kw) => text.includes(kw));
//     };

//     const fetchMenu = async () => {
//         try {
//             setLoading(true);
//             if (!restaurant) {
//                 setMenuItems([]);
//                 return;
//             }

//             // fetch a bunch of products and filter by category === restaurant.cuisines[0]
//             const res = await fetch(`${DUMMY_BASE}/products?limit=100`);
//             if (!res.ok) throw new Error('Failed to fetch menu from DummyJSON');
//             const json = await res.json();
//             const all = json.products || [];

//             // Filter by same category as the restaurant for demo mapping
//             const category = restaurant.cuisines && restaurant.cuisines[0];
//             let filtered = all.filter((p) => p.category === category);

//             // If none matched, fall back to all products (so your demo always shows something)
//             if (filtered.length === 0) filtered = all.slice(0, 30);

//             // Map DummyJSON product -> your menu item shape and add heuristic isVeg
//             const mappedItems = filtered.map((p) => ({
//                 _id: String(p.id),
//                 name: p.title,
//                 description: p.description,
//                 price: p.price,
//                 isVeg: guessIsVeg(p.title, p.description),
//                 image: p.thumbnail || (p.images && p.images[0]) || '',
//                 category: p.category || 'Other',
//                 raw: p,
//             }));

//             // Apply vegOnly filter if toggled
//             const finalItems = vegOnly ? mappedItems.filter((it) => it.isVeg) : mappedItems;

//             setMenuItems(finalItems);
//         } catch (error) {
//             console.error('Error fetching menu (dummy):', error);
//             setMenuItems([]);
//         } finally {
//             setLoading(false);
//         }
//     };

//     const getItemQuantity = (itemId) => {
//         const cartItem = cartItems.find((item) => {
//             // support both _id and id in cart items
//             if (!item) return false;
//             return item._id === itemId || String(item.id) === itemId;
//         });
//         return cartItem ? cartItem.quantity : 0;
//     };

//     // inside RestaurantMenu.jsx, add above handleAddToCart
//     const normalizeForCart = (item) => {
//         return {
//             _id: String(item._id || item.id),
//             id: item.id || item._id,
//             name: item.name || item.title || 'Item',
//             price: Number(item.price || (item.raw && item.raw.price) || 0),
//             image: item.image || (item.raw && (item.raw.thumbnail || (item.raw.images && item.raw.images[0]))) || '/placeholder.png',
//             restaurantId: restaurant?.id || restaurant?._id || null,
//             quantity: 1,
//             raw: item.raw || item,
//         };
//     };

//     const handleAddToCart = (item) => {
//         const cartItem = normalizeForCart(item);
//         const success = addToCart(cartItem, restaurant);
//         if (!success) return; // user cancelled clearing cart
//     };


//     const handleDecrement = (item) => {
//         const currentQty = getItemQuantity(item._id);
//         if (currentQty > 0) {
//             updateQuantity(item._id, currentQty - 1);
//         }
//     };

//     if (!restaurant) {
//         return (
//             <div>
//                 <Navbar />
//                 <div className="loading">Loading restaurant...</div>
//                 <Footer />
//             </div>
//         );
//     }

//     // Group menu items by category
//     const groupedItems = menuItems.reduce((acc, item) => {
//         const category = item.category || 'Other';
//         if (!acc[category]) {
//             acc[category] = [];
//         }
//         acc[category].push(item);
//         return acc;
//     }, {});

//     return (
//         <div className="restaurant-menu-page">
//             <Navbar />

//             <div className="container">
//                 {/* Restaurant Header */}
//                 <div className="restaurant-header">
//                     <div className="restaurant-image">
//                         <img src={restaurant.image} alt={restaurant.name} />
//                     </div>
//                     <div className="restaurant-details">
//                         <h1>{restaurant.name}</h1>
//                         <p className="cuisines">{restaurant.cuisines.join(', ')}</p>
//                         <p className="location">
//                             {restaurant.area}, {restaurant.city}
//                         </p>
//                         <div className="restaurant-meta">
//                             <span className="rating">
//                                 <FaStar /> {Number(restaurant.avgRating).toFixed(1)}
//                             </span>
//                             <span className="delivery-time">
//                                 <FaClock /> {restaurant.deliveryTime} mins
//                             </span>
//                             <span className="price">₹{restaurant.avgPrice} for two</span>
//                         </div>
//                     </div>
//                 </div>

//                 {/* Veg Filter */}
//                 <div className="menu-filters">
//                     <label className="veg-filter">
//                         <input
//                             type="checkbox"
//                             checked={vegOnly}
//                             onChange={(e) => setVegOnly(e.target.checked)}
//                         />
//                         <FaLeaf className="veg-icon" />
//                         Veg Only
//                     </label>
//                 </div>

//                 {/* Menu Items */}
//                 {loading ? (
//                     <div className="loading">Loading menu...</div>
//                 ) : (
//                     <div className="menu-section">
//                         {Object.keys(groupedItems).length > 0 ? (
//                             Object.keys(groupedItems).map((category) => (
//                                 <div key={category} className="category-section">
//                                     <h2>{category}</h2>
//                                     <div className="menu-items">
//                                         {groupedItems[category].map((item) => {
//                                             const quantity = getItemQuantity(item._id);
//                                             return (
//                                                 <div key={item._id} className="menu-item">
//                                                     <div className="item-info">
//                                                         <div className="item-type">
//                                                             {item.isVeg ? (
//                                                                 <span className="veg-badge">
//                                                                     <FaLeaf />
//                                                                 </span>
//                                                             ) : (
//                                                                 <span className="non-veg-badge">●</span>
//                                                             )}
//                                                         </div>
//                                                         <div>
//                                                             <h3>{item.name}</h3>
//                                                             {item.description && (
//                                                                 <p className="item-description">{item.description}</p>
//                                                             )}
//                                                             <p className="item-price">₹{item.price}</p>
//                                                         </div>
//                                                     </div>
//                                                     <div className="item-actions">
//                                                         {quantity === 0 ? (
//                                                             <button
//                                                                 className="btn-add"
//                                                                 onClick={() => handleAddToCart(item)}
//                                                             >
//                                                                 Add <FaPlus />
//                                                             </button>
//                                                         ) : (
//                                                             <div className="quantity-controls">
//                                                                 <button onClick={() => handleDecrement(item)}>
//                                                                     <FaMinus />
//                                                                 </button>
//                                                                 <span>{quantity}</span>
//                                                                 <button onClick={() => handleIncrement(item)}>
//                                                                     <FaPlus />
//                                                                 </button>
//                                                             </div>
//                                                         )}
//                                                     </div>
//                                                 </div>
//                                             );
//                                         })}
//                                     </div>
//                                 </div>
//                             ))
//                         ) : (
//                             <div className="no-items">
//                                 <p>No menu items available.</p>
//                             </div>
//                         )}
//                     </div>
//                 )}

//                 {/* View Cart Button */}
//                 {cartItems.length > 0 && (
//                     <div className="cart-footer">
//                         <button className="btn btn-primary" onClick={() => navigate('/cart')}>
//                             View Cart ({cartItems.length} {cartItems.length === 1 ? 'item' : 'items'})
//                         </button>
//                     </div>
//                 )}
//             </div>

//             <Footer />
//         </div>
//     );
// };

// export default RestaurantMenu;












import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import Navbar from '../../components/layout/Navbar';
import Footer from '../../components/layout/Footer';
import api from '../../utils/api';
import { useCart } from '../../context/CartContext';
import { FaStar, FaClock, FaLeaf, FaPlus, FaMinus } from 'react-icons/fa';
import './RestaurantMenu.css';

const RestaurantMenu = () => {
    const { id } = useParams();
    const navigate = useNavigate();
    const { addToCart, cartItems, updateQuantity } = useCart();

    const [restaurant, setRestaurant] = useState(null);
    const [menuItems, setMenuItems] = useState([]);
    const [loading, setLoading] = useState(true);
    const [vegOnly, setVegOnly] = useState(false);

    useEffect(() => {
        fetchRestaurant();
        fetchMenu();
    }, [id]);

    useEffect(() => {
        fetchMenu();
    }, [vegOnly]);

    const fetchRestaurant = async () => {
        try {
            const response = await api.get(`/restaurants/${id}`);
            setRestaurant(response.data.data);
        } catch (error) {
            console.error('Error fetching restaurant:', error);
        }
    };

    const fetchMenu = async () => {
        try {
            setLoading(true);
            const params = vegOnly ? '?isVeg=true' : '';
            const response = await api.get(`/restaurants/${id}/menu${params}`);
            setMenuItems(response.data.data || []);
        } catch (error) {
            console.error('Error fetching menu:', error);
            setMenuItems([]);
        } finally {
            setLoading(false);
        }
    };

    const getItemQuantity = (itemId) => {
        const cartItem = cartItems.find((item) => item._id === itemId);
        return cartItem ? cartItem.quantity : 0;
    };

    const handleAddToCart = (item) => {
        const success = addToCart(item, restaurant);
        if (!success) {
            // User cancelled cart clear
            return;
        }
    };

    const handleIncrement = (item) => {
        const currentQty = getItemQuantity(item._id);
        if (currentQty === 0) {
            handleAddToCart(item);
        } else {
            updateQuantity(item._id, currentQty + 1);
        }
    };

    const handleDecrement = (item) => {
        const currentQty = getItemQuantity(item._id);
        if (currentQty > 0) {
            updateQuantity(item._id, currentQty - 1);
        }
    };

    if (!restaurant) {
        return (
            <div>
                <Navbar />
                <div className="loading">Loading restaurant...</div>
                <Footer />
            </div>
        );
    }

    // Group menu items by category
    const groupedItems = menuItems.reduce((acc, item) => {
        const category = item.category || 'Other';
        if (!acc[category]) {
            acc[category] = [];
        }
        acc[category].push(item);
        return acc;
    }, {});

    return (
        <div className="restaurant-menu-page">
            <Navbar />

            <div className="container">
                {/* Restaurant Header */}
                <div className="restaurant-header">
                    <div className="restaurant-image">
                        <img src={restaurant.image} alt={restaurant.name} />
                    </div>
                    <div className="restaurant-details">
                        <h1>{restaurant.name}</h1>
                        <p className="cuisines">{restaurant.cuisines.join(', ')}</p>
                        <p className="location">
                            {restaurant.area}, {restaurant.city}
                        </p>
                        <div className="restaurant-meta">
                            <span className="rating">
                                <FaStar /> {restaurant.avgRating.toFixed(1)}
                            </span>
                            <span className="delivery-time">
                                <FaClock /> {restaurant.deliveryTime} mins
                            </span>
                            <span className="price">₹{restaurant.avgPrice} for two</span>
                        </div>
                    </div>
                </div>

                {/* Veg Filter */}
                <div className="menu-filters">
                    <label className="veg-filter">
                        <input
                            type="checkbox"
                            checked={vegOnly}
                            onChange={(e) => setVegOnly(e.target.checked)}
                        />
                        <FaLeaf className="veg-icon" />
                        Veg Only
                    </label>
                </div>

                {/* Menu Items */}
                {loading ? (
                    <div className="loading">Loading menu...</div>
                ) : (
                    <div className="menu-section">
                        {Object.keys(groupedItems).length > 0 ? (
                            Object.keys(groupedItems).map((category) => (
                                <div key={category} className="category-section">
                                    <h2>{category}</h2>
                                    <div className="menu-items">
                                        {groupedItems[category].map((item) => {
                                            const quantity = getItemQuantity(item._id);
                                            return (
                                                <div key={item._id} className="menu-item">
                                                    <div className="item-info">
                                                        <div className="item-type">
                                                            {item.isVeg ? (
                                                                <span className="veg-badge">
                                                                    <FaLeaf />
                                                                </span>
                                                            ) : (
                                                                <span className="non-veg-badge">●</span>
                                                            )}
                                                        </div>
                                                        <div>
                                                            <h3>{item.name}</h3>
                                                            {item.description && (
                                                                <p className="item-description">{item.description}</p>
                                                            )}
                                                            <p className="item-price">₹{item.price}</p>
                                                        </div>
                                                    </div>
                                                    <div className="item-actions">
                                                        {quantity === 0 ? (
                                                            <button
                                                                className="btn-add"
                                                                onClick={() => handleAddToCart(item)}
                                                            >
                                                                Add <FaPlus />
                                                            </button>
                                                        ) : (
                                                            <div className="quantity-controls">
                                                                <button onClick={() => handleDecrement(item)}>
                                                                    <FaMinus />
                                                                </button>
                                                                <span>{quantity}</span>
                                                                <button onClick={() => handleIncrement(item)}>
                                                                    <FaPlus />
                                                                </button>
                                                            </div>
                                                        )}
                                                    </div>
                                                </div>
                                            );
                                        })}
                                    </div>
                                </div>
                            ))
                        ) : (
                            <div className="no-items">
                                <p>No menu items available.</p>
                            </div>
                        )}
                    </div>
                )}

                {/* View Cart Button */}
                {cartItems.length > 0 && (
                    <div className="cart-footer">
                        <button className="btn btn-primary" onClick={() => navigate('/cart')}>
                            View Cart ({cartItems.length} {cartItems.length === 1 ? 'item' : 'items'})
                        </button>
                    </div>
                )}
            </div>

            <Footer />
        </div>
    );
};

export default RestaurantMenu;
