import { Link } from 'react-router-dom';
import { FaUtensils, FaShippingFast, FaMapMarkerAlt } from 'react-icons/fa';
import Navbar from '../components/layout/Navbar';
import Footer from '../components/layout/Footer';
import './Landing.css';

const Landing = () => {
    return (
        <div className="landing-page">
            <Navbar />

            <section className="hero">
                <div className="container">
                    <div className="hero-content">
                        <h1>Delicious Food Delivered to Your Doorstep</h1>
                        <p>Order from your favorite local restaurants with just a few clicks</p>
                        <div className="hero-buttons">
                            <Link to="/register" className="btn btn-primary btn-large">
                                Get Started
                            </Link>
                            <Link to="/login" className="btn btn-outline btn-large">
                                Login
                            </Link>
                        </div>
                    </div>
                </div>
            </section>

            <section className="features">
                <div className="container">
                    <h2>Why Choose Delivr?</h2>
                    <div className="features-grid">
                        <div className="feature-card">
                            <FaUtensils className="feature-icon" />
                            <h3>Wide Selection</h3>
                            <p>Browse thousands of restaurants and cuisines in your area</p>
                        </div>
                        <div className="feature-card">
                            <FaShippingFast className="feature-icon" />
                            <h3>Fast Delivery</h3>
                            <p>Get your food delivered hot and fresh in 30-60 minutes</p>
                        </div>
                        <div className="feature-card">
                            <FaMapMarkerAlt className="feature-icon" />
                            <h3>Live Tracking</h3>
                            <p>Track your order in real-time from restaurant to your door</p>
                        </div>
                    </div>
                </div>
            </section>

            <section className="cta">
                <div className="container">
                    <h2>Ready to order?</h2>
                    <p>Join thousands of satisfied customers enjoying great food</p>
                    <Link to="/register" className="btn btn-primary btn-large">
                        Sign Up Now
                    </Link>
                </div>
            </section>

            <Footer />
        </div>
    );
};

export default Landing;
